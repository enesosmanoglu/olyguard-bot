const db = require("quick.db");
module.exports = client => {
  
  
};