# ✧ OLYGUARD

[**✧ OLYMPOS**](https://www.olymposweb.com) [Discord sunucusu](https://discord.gg/5bzJr2d) için hazırlanmış güvenlik botudur.


-ria & jamie