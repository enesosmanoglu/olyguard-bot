

module.exports = client => {
    console.log(`Bot aktif, ${client.commands.size} komut yüklendi!`);
    console.log(`${client.user.tag} giriş yaptı.`);
};
